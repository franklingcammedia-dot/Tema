<?php if(!function_exists('nestnet_configs')){
    function nestnet_configs($value){
        $configs = [
            'theme_colors' => [
                'primary'   => [
                    'title' => esc_html__('Primary', 'nestnet'), 
                    'value' => nestnet()->get_opt('primary_color', '#EF4824')
                ],
                'secondary'   => [
                    'title' => esc_html__('Secondary', 'nestnet'), 
                    'value' => nestnet()->get_opt('secondary_color', '#616670')
                ],
                'body-bg'   => [
                    'title' => esc_html__('Body Background Color', 'nestnet'), 
                    'value' => nestnet()->get_page_opt('body_bg_color', '#fff')
                ]
            ],
            'link' => [
                'color' => nestnet()->get_opt('link_color', ['regular' => '#1D1D1D'])['regular'],
                'color-hover'   => nestnet()->get_opt('link_color', ['hover' => '#EF4824'])['hover'],
                'color-active'  => nestnet()->get_opt('link_color', ['active' => '#EF4824'])['active'],
            ],
            'gradient' => [
                'color-from' => nestnet()->get_opt('gradient_color', ['from' => '#EF4824'])['from'],
                'color-to' => nestnet()->get_opt('gradient_color', ['to' => '#EF4824'])['to'],
            ],
               
        ];
        return $configs[$value];
    }
}
if(!function_exists('nestnet_inline_styles')) {
    function nestnet_inline_styles() {  
        
        $theme_colors      = nestnet_configs('theme_colors');
        $link_color        = nestnet_configs('link');
        $gradient_color    = nestnet_configs('gradient');
        ob_start();
        echo ':root{';
            
            foreach ($theme_colors as $color => $value) {
                printf('--%1$s-color: %2$s;', str_replace('#', '',$color),  $value['value']);
            }
            foreach ($theme_colors as $color => $value) {
                printf('--%1$s-color-rgb: %2$s;', str_replace('#', '',$color),  nestnet_hex_rgb($value['value']));
            }
            foreach ($link_color as $color => $value) {
                printf('--link-%1$s: %2$s;', $color, $value);
            }
            foreach ($gradient_color as $color => $value) {
                printf('--gradient-%1$s: %2$s;', $color, $value);
            }
        echo '}';

        return ob_get_clean();
         
    }
}
 