<?php

if( !defined( 'ABSPATH' ) )
	exit; 

class Nestnet_Admin_Templates extends Nestnet_Base{

	public function __construct() {
		$this->add_action( 'admin_menu', 'register_page', 20 );
	}
 
	public function register_page() {
		add_submenu_page(
			'pxlart',
		    esc_html__( 'Templates', 'nestnet' ),
		    esc_html__( 'Templates', 'nestnet' ),
		    'manage_options',
		    'edit.php?post_type=pxl-template',
		    false
		);
	}
}
new Nestnet_Admin_Templates;
