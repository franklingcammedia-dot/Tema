<?php

$uri = get_template_directory_uri() . '/inc/admin/demo-data/demo-imgs/';
// Demos
$demos = array(
	// Elementor Demos
	'nestnet' => array(
		'title'       => 'Nestnet',	
		'description' => '',
		'screenshot'  => $uri . 'nestnet.png',
		'preview'     => 'https://demo.bravisthemes.com/nestnet/',
	),
);