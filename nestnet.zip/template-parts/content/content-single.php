<?php
/**
 * Template part for displaying posts in loop
 *
 * @package Bravis-Themes
 */
$post_tag = nestnet()->get_theme_opt( 'post_tag', true );
$post_navigation = nestnet()->get_theme_opt( 'post_navigation', false );
$post_author_info = nestnet()->get_theme_opt( 'post_author_info', false );
$tags_list = get_the_tag_list();
$post_date = nestnet()->get_theme_opt( 'post_date', true );
$map_text = nestnet()->get_theme_opt('map_text');
?>
<article id="pxl-post-<?php the_ID(); ?>" <?php post_class('pxl---post'); ?>>
    <h2 class="entry-title">
        <p title="<?php the_title(); ?>">
            <?php if(is_sticky()) { ?>
                <i class="bravisicon-tick"></i>
            <?php } ?>
            <?php the_title(); ?>
        </p>
    </h2>
    <?php if (has_post_thumbnail()) {
        echo '<div class="pxl-post-image">'; ?>
            <?php the_post_thumbnail('nestnet-large'); ?>
        <?php echo '</div>';
    }?>
    <?php nestnet()->blog->get_post_metas(); ?>
    <div class="pxl-item--holder">
        <div class="pxl-item--content clearfix">
            <?php
                the_content();
                wp_link_pages( array(
                    'before'      => '<div class="page-links">',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ) );
            ?>
        </div>

    </div>
    <div class="pxl-content-footer">
        <?php if($post_tag && $tags_list) :  ?>
            <div class="pxl--post-tag">
                <?php if($post_tag) { nestnet()->blog->get_tagged_in(); } ?>
            </div>
        <?php endif; ?>
        <div class="pxl-map-text">
            <i class="flaticon flaticon-maps-and-flags"></i>
            <?php echo nestnet_html($map_text); ?>
        </div>
    </div>

    <?php if($post_author_info) { nestnet()->blog->get_post_author_info(); } ?>

    <?php if($post_navigation) { nestnet()->blog->get_post_nav(); } ?>
</article><!-- #post -->