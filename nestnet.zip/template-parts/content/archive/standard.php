<?php
/**
 * @package Bravis-Themes
 */
$archive_author = nestnet()->get_theme_opt( 'archive_author', true );
$post_comments_on = nestnet()->get_theme_opt( 'post_comments_on', true );
$post_like = nestnet()->get_theme_opt( 'post_like', true );
$archive_readmore_text = nestnet()->get_theme_opt('archive_readmore_text', esc_html__('Read more', 'nestnet'));
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('pxl---post pxl-item--archive pxl-item--standard'); ?>>
    <?php if (has_post_thumbnail()) { 
        echo '<div class="pxl-item--image">'; ?>
            <a href="<?php echo esc_url( get_permalink()); ?>"><?php the_post_thumbnail('nestnet-large'); ?></a>
        <?php echo '</div>';
    } ?>
    <?php nestnet()->blog->get_archive_meta(); ?>
    <div class="pxl-item--excerpt">
        <?php
            nestnet()->blog->get_excerpt();
            wp_link_pages( array(
                'before'      => '<div class="page-links">',
                'after'       => '</div>',
                'link_before' => '<span>',
                'link_after'  => '</span>',
            ) );
        ?>
    </div>
    <div class="pxl-item--bottom">
    	<?php if($archive_author || $post_like  || $post_comments_on) : ?>
            <div class="pxl-item--content">
                <ul class="pxl-item-list-meta">
                    <?php if($archive_author) : ?>
                        <li class="pxl-author">
                            <span class="entry-author-avatar">
                                <?php echo get_avatar( get_the_author_meta( 'ID' ), 160 ); ?>
                            </span>
                            <span class="author-name">
                                <?php echo esc_html__('By', 'nestnet'); ?>&nbsp;<?php the_author_posts_link(); ?>
                            </span>
                        </li>
                    <?php endif; ?>
                    <?php if($post_like) : ?>
	                    <li class="pxl--item-like">
	                        <?php echo get_simple_likes_button($post->ID ); ?>
	                    </li>
	                <?php endif; ?>
                    <?php if($post_comments_on) : ?>
                        <li class="item-comment">
                            <a href="<?php the_permalink(); ?>">
                                <i class="icofont-speech-comments"></i>
                                <?php echo comments_number(esc_html__('0 Comments', 'nestnet'),esc_html__('1 Comment', 'nestnet'),esc_html__('% Comments', 'nestnet')); ?>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
                <a class="btn--readmore" href="<?php echo esc_url( get_permalink()); ?>">
		            <span><?php echo nestnet_html($archive_readmore_text); ?><p>+</p></span>
		        </a>
            </div>
        <?php endif; ?>
    </div>
</article>