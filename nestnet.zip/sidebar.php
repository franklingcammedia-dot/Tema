<?php
/**
 * @package Bravis-Themes
 */

dynamic_sidebar( nestnet()->get_sidebar() );