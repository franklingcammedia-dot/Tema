<?php 
$template = (int)$widget->get_setting('content_template','0');
if($template > 0 ){
	if ( !has_action( 'pxl_anchor_target_hidden_panel_'.$template) ){
		add_action( 'pxl_anchor_target_hidden_panel_'.$template, 'nestnet_hook_anchor_hidden_panel' );
	} 
}
?>
<div class="pxl-hidden-panel-button pxl-anchor-button1 pxl-cursor--cta">
	<ul class="pxl-button-sidebar">
		<li class="pxl-icon-line pxl-icon-line1"><span></span></li>
		<li class="pxl-icon-line pxl-icon-line2"><span></span></li>
		<li class="pxl-icon-line pxl-icon-line3"><span></span></li>
	</ul>
</div>