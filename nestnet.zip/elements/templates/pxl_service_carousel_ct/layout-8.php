<?php
$col_xs = $widget->get_setting('col_xs', '');
$col_sm = $widget->get_setting('col_sm', '');
$col_md = $widget->get_setting('col_md', '');
$col_lg = $widget->get_setting('col_lg', '');
$col_xl = $widget->get_setting('col_xl', '');
$col_xxl = $widget->get_setting('col_xxl', '');
if($col_xxl == 'inherit') {
    $col_xxl = $col_xl;
}
$slides_to_scroll = $widget->get_setting('slides_to_scroll', '');
$arrows = $widget->get_setting('arrows','false');  
$pagination = $widget->get_setting('pagination','false');
$pagination_type = $widget->get_setting('pagination_type','bullets');
$pause_on_hover = $widget->get_setting('pause_on_hover');
$autoplay = $widget->get_setting('autoplay', '');
$autoplay_speed = $widget->get_setting('autoplay_speed', '5000');
$infinite = $widget->get_setting('infinite','false');  
$drap = $widget->get_setting('drap','false');  
$speed = $widget->get_setting('speed', '500');
$opts = [
    'slide_direction'               => 'horizontal',
    'slide_percolumn'               => '1', 
    'slide_mode'                    => 'slide', 
    'slides_to_show'                => $col_xl, 
    'slides_to_show_xxl'             => $col_xxl, 
    'slides_to_show_lg'             => $col_lg, 
    'slides_to_show_md'             => $col_md, 
    'slides_to_show_sm'             => $col_sm, 
    'slides_to_show_xs'             => $col_xs, 
    'slides_to_scroll'              => $slides_to_scroll,
    'arrow'                         => $arrows,
    'pagination'                    => $pagination,
    'pagination_type'               => $pagination_type,
    'pagination_number'             => 'true',
    'autoplay'                      => $autoplay,
    'pause_on_hover'                => $pause_on_hover,
    'pause_on_interaction'          => 'true',
    'delay'                         => $autoplay_speed,
    'loop'                          => $infinite,
    'speed'                         => $speed,
];
$widget->add_render_attribute( 'carousel', [
    'class'         => 'pxl-swiper-container',
    'dir'           => is_rtl() ? 'rtl' : 'ltr',
    'data-settings' => wp_json_encode($opts)
]);
if(isset($settings['services8']) && !empty($settings['services8']) && count($settings['services8'])): 
    $is_new = \Elementor\Icons_Manager::is_migration_allowed();
?>
    <div class="pxl-swiper-sliders pxl-service-carousel-custom pxl-service-carousel-custom8 pxl-swiper-boxshadow" <?php if($drap !== 'false') : ?>data-cursor-drap="<?php echo esc_html('DRAG', 'nestnet'); ?>"<?php endif; ?>>
        <?php if($arrows !== 'false'): ?>
            <div class="pxl-swiper-arrow-wrap">
                <div class="pxl-swiper-arrow pxl-swiper-arrow-prev"><i class="far fa-arrow-left rtl-icon"></i></div>
                <div class="pxl-swiper-arrow pxl-swiper-arrow-next"><i class="far fa-arrow-right rtl-icon"></i></div>
            </div>
        <?php endif; ?>

        <div class="pxl-carousel-inner">
            <div <?php pxl_print_html($widget->get_render_attribute_string( 'carousel' )); ?>>
                <div class="pxl-swiper-wrapper">
                    <?php foreach ($settings['services8'] as $key => $value):
                        $icon_key = $widget->get_repeater_setting_key( 'pxl_icon_lv8', 'services8', $key );
                        $widget->add_render_attribute( $icon_key, [
                            'class' => $value['pxl_icon_lv8'],
                            'aria-hidden' => 'true',
                        ] );
                        $link_key = $widget->get_repeater_setting_key( 'link_lv8', 'value', $key );
                        if ( ! empty( $value['link_lv8']['url'] ) ) {
                            $widget->add_render_attribute( $link_key, 'href', $value['link_lv8']['url'] );

                            if ( $value['link_lv8']['is_external'] ) {
                                $widget->add_render_attribute( $link_key, 'target', '_blank' );
                            }

                            if ( $value['link_lv8']['nofollow'] ) {
                                $widget->add_render_attribute( $link_key, 'rel', 'nofollow' );
                            }
                        }
                        $link_attributes = $widget->get_render_attribute_string( $link_key );
                        $title_lv8 = isset($value['title_lv8']) ? $value['title_lv8'] : '';
                        $desc_lv8 = isset($value['desc_lv8']) ? $value['desc_lv8'] : '';
                        ?>
                        <div class="pxl-swiper-slide">
                            <div class="pxl-item--inner <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
                                <div class="item--meta">
                                    <div class="pxl-item--icon">
                                        <?php if ( $is_new ):
                                            \Elementor\Icons_Manager::render_icon( $value['pxl_icon_lv8'], [ 'aria-hidden' => 'true' ] );
                                        elseif(!empty($value['pxl_icon_lv8'])): ?>
                                            <i class="<?php echo esc_attr( $value['pxl_icon_lv8'] ); ?>" aria-hidden="true"></i>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="pxl-item--holder">
                                    <a class="pxl-item--title el-empty" <?php echo implode( ' ', [ $link_attributes ] ); ?>>
                                        <?php echo pxl_print_html($title_lv8); ?>
                                    </a>
                                    <div class="pxl-item--desc"><?php echo pxl_print_html($desc_lv8); ?></div>
                                </div>
                           </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?php if($pagination !== 'false'): ?>
            <div class="pxl-swiper-dots style-1"></div>
        <?php endif; ?>
        
    </div>
<?php endif; ?>
