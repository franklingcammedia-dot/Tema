<?php
$col_xs = $widget->get_setting('col_xs', '');
$col_sm = $widget->get_setting('col_sm', '');
$col_md = $widget->get_setting('col_md', '');
$col_lg = $widget->get_setting('col_lg', '');
$col_xl = $widget->get_setting('col_xl', '');
$col_xxl = $widget->get_setting('col_xxl', '');
if($col_xxl == 'inherit') {
    $col_xxl = $col_xl;
}
$slides_to_scroll = $widget->get_setting('slides_to_scroll', '');
$arrows = $widget->get_setting('arrows','false');  
$pagination = $widget->get_setting('pagination','false');
$pagination_type = $widget->get_setting('pagination_type','bullets');
$pause_on_hover = $widget->get_setting('pause_on_hover');
$autoplay = $widget->get_setting('autoplay', '');
$autoplay_speed = $widget->get_setting('autoplay_speed', '5000');
$infinite = $widget->get_setting('infinite','false');  
$drap = $widget->get_setting('drap','false');  
$speed = $widget->get_setting('speed', '500');
$opts = [
    'slide_direction'               => 'horizontal',
    'slide_percolumn'               => '1', 
    'slide_mode'                    => 'slide', 
    'slides_to_show'                => $col_xl, 
    'slides_to_show_xxl'             => $col_xxl, 
    'slides_to_show_lg'             => $col_lg, 
    'slides_to_show_md'             => $col_md, 
    'slides_to_show_sm'             => $col_sm, 
    'slides_to_show_xs'             => $col_xs, 
    'slides_to_scroll'              => $slides_to_scroll,
    'arrow'                         => $arrows,
    'pagination'                    => $pagination,
    'pagination_type'               => $pagination_type,
    'pagination_number'             => 'true',
    'autoplay'                      => $autoplay,
    'pause_on_hover'                => $pause_on_hover,
    'pause_on_interaction'          => 'true',
    'delay'                         => $autoplay_speed,
    'loop'                          => $infinite,
    'speed'                         => $speed,
];
$widget->add_render_attribute( 'carousel', [
    'class'         => 'pxl-swiper-container',
    'dir'           => is_rtl() ? 'rtl' : 'ltr',
    'data-settings' => wp_json_encode($opts)
]);
if(isset($settings['services_lv3']) && !empty($settings['services_lv3']) && count($settings['services_lv3'])): 
$image_size = !empty($settings['img_size']) ? $settings['img_size'] : '810x610';
$is_new = \Elementor\Icons_Manager::is_migration_allowed();
?>
    <div class="pxl-swiper-sliders pxl-service-carousel-custom pxl-service-carousel-custom3 pxl-swiper-boxshadow" <?php if($drap !== 'false') : ?>data-cursor-drap="<?php echo esc_html('DRAG', 'nestnet'); ?>"<?php endif; ?>>
        <div class="pxl-carousel-inner">
            <div <?php pxl_print_html($widget->get_render_attribute_string( 'carousel' )); ?>>
                <div class="pxl-swiper-wrapper">
                    <?php foreach ($settings['services_lv3'] as $key => $value):
                        $icon_key = $widget->get_repeater_setting_key( 'pxl_icon_lv3', 'services_lv3', $key );
                        $widget->add_render_attribute( $icon_key, [
                            'class' => $value['pxl_icon_lv3'],
                            'aria-hidden' => 'true',
                        ] );
                        $link_key = $widget->get_repeater_setting_key( 'link_lv3', 'value', $key );
                        if ( ! empty( $value['link_lv3']['url'] ) ) {
                            $widget->add_render_attribute( $link_key, 'href', $value['link_lv3']['url'] );

                            if ( $value['link_lv3']['is_external'] ) {
                                $widget->add_render_attribute( $link_key, 'target', '_blank' );
                            }

                            if ( $value['link_lv3']['nofollow'] ) {
                                $widget->add_render_attribute( $link_key, 'rel', 'nofollow' );
                            }
                        }
                        $link_attributes = $widget->get_render_attribute_string( $link_key );

                        $image_lv3 = isset($value['image_lv3']) ? $value['image_lv3'] : '';
                        $title_lv3 = isset($value['title_lv3']) ? $value['title_lv3'] : '';
                        $desc_lv3 = isset($value['desc_lv3']) ? $value['desc_lv3'] : '';
                        $button_text_lv3 = isset($value['button_text_lv3']) ? $value['button_text_lv3'] : '';
                        ?>
                        <div class="pxl-swiper-slide">
                            <div class="pxl-item--inner <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
                                <div class="pxl-link-image">
                                    <a <?php echo implode( ' ', [ $link_attributes ] ); ?>>
                                        <?php if(!empty($image_lv3['id'])) { 
                                            $img = pxl_get_image_by_size( array(
                                                'attach_id'  => $image_lv3['id'],
                                                'thumb_size' => $image_size,
                                                'class' => 'no-lazyload',
                                            ));
                                            $thumbnail = $img['thumbnail'];
                                            ?>
                                            <div class="pxl-item--image">
                                                <?php echo wp_kses_post($thumbnail); ?>
                                            </div>
                                            <div class="pxl-item--icon">
                                                <?php if ( $is_new ):
                                                    \Elementor\Icons_Manager::render_icon( $value['pxl_icon_lv3'], [ 'aria-hidden' => 'true' ] );
                                                elseif(!empty($value['pxl_icon_lv3'])): ?>
                                                    <i class="<?php echo esc_attr( $value['pxl_icon_lv3'] ); ?>" aria-hidden="true"></i>
                                                <?php endif; ?>
                                            </div>
                                        <?php } ?>
                                    </a>
                                </div>
                                <div class="pxl-item--holder">
                                    <h5 class="pxl-item--title el-empty">
                                        <?php echo pxl_print_html($title_lv3); ?>
                                    </h5>
                                    <div class="pxl-item--desc el-empty"><?php echo pxl_print_html($desc_lv3); ?></div>
                                    <a class="pxl-btn-service" <?php echo implode( ' ', [ $link_attributes ] ); ?>>
                                        <?php echo pxl_print_html($button_text_lv3); ?>
                                        <i class="far fa-plus pxl-ml-5"></i>
                                    </a>
                                </div>
                           </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?php if($pagination !== 'false'): ?>
            <div class="pxl-swiper-dots style-1"></div>
        <?php endif; ?>

        <?php if($arrows !== 'false'): ?>
            <div class="pxl-swiper-arrow-wrap">
                <div class="pxl-swiper-arrow pxl-swiper-arrow-prev"><i class="caseicon-angle-arrow-left rtl-icon"></i></div>
                <div class="pxl-swiper-arrow pxl-swiper-arrow-next"><i class="caseicon-angle-arrow-right rtl-icon"></i></div>
            </div>
        <?php endif; ?>
        
    </div>
<?php endif; ?>
