<?php
$col_xs = $widget->get_setting('col_xs', '');
$col_sm = $widget->get_setting('col_sm', '');
$col_md = $widget->get_setting('col_md', '');
$col_lg = $widget->get_setting('col_lg', '');
$col_xl = $widget->get_setting('col_xl', '');
$col_xxl = $widget->get_setting('col_xxl', '');
if($col_xxl == 'inherit') {
    $col_xxl = $col_xl;
}
$slides_to_scroll = $widget->get_setting('slides_to_scroll', '');
$arrows = $widget->get_setting('arrows','false');  
$pagination = $widget->get_setting('pagination','false');
$pagination_type = $widget->get_setting('pagination_type','bullets');
$pause_on_hover = $widget->get_setting('pause_on_hover');
$autoplay = $widget->get_setting('autoplay', '');
$autoplay_speed = $widget->get_setting('autoplay_speed', '5000');
$infinite = $widget->get_setting('infinite','false');  
$drap = $widget->get_setting('drap','false');  
$speed = $widget->get_setting('speed', '500');
$opts = [
    'slide_direction'               => 'horizontal',
    'slide_percolumn'               => '1', 
    'slide_mode'                    => 'slide', 
    'slides_to_show'                => $col_xl, 
    'slides_to_show_xxl'             => $col_xxl, 
    'slides_to_show_lg'             => $col_lg, 
    'slides_to_show_md'             => $col_md, 
    'slides_to_show_sm'             => $col_sm, 
    'slides_to_show_xs'             => $col_xs, 
    'slides_to_scroll'              => $slides_to_scroll,
    'arrow'                         => $arrows,
    'pagination'                    => $pagination,
    'pagination_type'               => $pagination_type,
    'pagination_number'             => 'true',
    'autoplay'                      => $autoplay,
    'pause_on_hover'                => $pause_on_hover,
    'pause_on_interaction'          => 'true',
    'delay'                         => $autoplay_speed,
    'loop'                          => $infinite,
    'speed'                         => $speed,
];
$widget->add_render_attribute( 'carousel', [
    'class'         => 'pxl-swiper-container',
    'dir'           => is_rtl() ? 'rtl' : 'ltr',
    'data-settings' => wp_json_encode($opts)
]);
if(isset($settings['services2']) && !empty($settings['services2']) && count($settings['services2'])): 
    $is_new = \Elementor\Icons_Manager::is_migration_allowed();
?>
    <div class="pxl-swiper-sliders pxl-service-carousel-custom pxl-service-carousel-custom6 pxl-swiper-boxshadow" <?php if($drap !== 'false') : ?>data-cursor-drap="<?php echo esc_html('DRAG', 'nestnet'); ?>"<?php endif; ?>>
        <div class="pxl-carousel-inner">
            <div <?php pxl_print_html($widget->get_render_attribute_string( 'carousel' )); ?>>
                <div class="pxl-swiper-wrapper">
                    <?php foreach ($settings['services2'] as $key => $value):
                        $icon_key = $widget->get_repeater_setting_key( 'pxl_icon', 'services2', $key );
                        $widget->add_render_attribute( $icon_key, [
                            'class' => $value['pxl_icon'],
                            'aria-hidden' => 'true',
                        ] );
                        $link_key = $widget->get_repeater_setting_key( 'link_lv2', 'value', $key );
                        if ( ! empty( $value['link_lv2']['url'] ) ) {
                            $widget->add_render_attribute( $link_key, 'href', $value['link_lv2']['url'] );

                            if ( $value['link_lv2']['is_external'] ) {
                                $widget->add_render_attribute( $link_key, 'target', '_blank' );
                            }

                            if ( $value['link_lv2']['nofollow'] ) {
                                $widget->add_render_attribute( $link_key, 'rel', 'nofollow' );
                            }
                        }
                        $number = isset($value['number']) ? $value['number'] : '';
                        $link_attributes = $widget->get_render_attribute_string( $link_key );
                        $title_lv2 = isset($value['title_lv2']) ? $value['title_lv2'] : '';
                        $desc_lv2 = isset($value['desc_lv2']) ? $value['desc_lv2'] : '';
                        ?>
                        <div class="pxl-swiper-slide">
                            <div class="pxl-item--inner <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
                                <div class="item--meta">
                                    <div class="pxl-layout-icon">
                                        <div class="pxl-item--icon">
                                            <?php if ( $is_new ):
                                                \Elementor\Icons_Manager::render_icon( $value['pxl_icon'], [ 'aria-hidden' => 'true' ] );
                                            elseif(!empty($value['pxl_icon'])): ?>
                                                <i class="<?php echo esc_attr( $value['pxl_icon'] ); ?>" aria-hidden="true"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div class="pxl-item--icon2">
                                            <svg width="124" height="112" viewBox="0 0 124 112" fill="#EF4824" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M59.1144 0.0619809C72.8435 0.589401 84.7273 7.27093 95.4296 15.7796C107.9 25.6945 124.398 35.8369 123.993 51.6425C123.589 67.3688 105.919 75.7174 93.6354 85.7335C83.1 94.3242 72.4546 101.632 59.1144 104.545C40.7996 108.546 17.6038 118.803 4.9869 105.096C-7.69275 91.3207 7.45386 70.0266 10.4187 51.6425C12.6192 37.9982 10.319 22.9822 19.8595 12.8765C29.6291 2.52816 44.7986 -0.487975 59.1144 0.0619809Z" fill-opacity="0.1"/>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                                <div class="pxl-item--holder">
                                    <h5 class="pxl-item--title el-empty">
                                        <?php echo pxl_print_html($title_lv2); ?>
                                    </h5>
                                    <div class="pxl-item--desc el-empty"><?php echo pxl_print_html($desc_lv2); ?></div>
                                </div>
                                <div class="pxl-item-bottom">
                                    <div class="pxl-item--number"><?php echo pxl_print_html($number); ?></div>
                                    <a class="pxl-btn-service" <?php echo implode( ' ', [ $link_attributes ] ); ?>>
                                        <i class="flaticon flaticon-right"></i>
                                    </a>
                                </div>
                           </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?php if($pagination !== 'false'): ?>
            <div class="pxl-swiper-dots style-1"></div>
        <?php endif; ?>

        <?php if($arrows !== 'false'): ?>
            <div class="pxl-swiper-arrow-wrap">
                <div class="pxl-swiper-arrow pxl-swiper-arrow-prev"><i class="caseicon-angle-arrow-left rtl-icon"></i></div>
                <div class="pxl-swiper-arrow pxl-swiper-arrow-next"><i class="caseicon-angle-arrow-right rtl-icon"></i></div>
            </div>
        <?php endif; ?>
        
    </div>
<?php endif; ?>
