<?php
$widget->add_render_attribute( 'counter', [
    'class' => 'pxl--counter-value '.$settings['effect'].'',
    'data-duration' => $settings['duration'],
    'data-startnumber' => $settings['starting_number'],
    'data-endnumber' => $settings['ending_number'],
    'data-to-value' => $settings['ending_number'],
    'data-delimiter' => $settings['thousand_separator_char'],
] ); ?>
<div class="pxl-counter pxl-counter2 ">
    <div class="pxl--item-inner">
        <div class="pxl--counter-meta <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
            <div class="pxl--counter-number">
                <?php if ( $settings['icon_type'] == 'icon' && !empty($settings['pxl_icon']['value']) ) : ?>
                    <div class="pxl-item--icon">
                        <?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                    </div>
                <?php endif; ?>
                <div class="pxl-counter-meta">
                    <span class="pxl--counter-prefix el-empty"><?php echo pxl_print_html($settings['prefix']); ?></span>
                    <span <?php pxl_print_html($widget->get_render_attribute_string( 'counter' )); ?>><?php echo esc_html($settings['starting_number']); ?></span>
                    <?php if(!empty($settings['suffix'])) : ?>
                        <span class="pxl--counter-suffix"><?php echo pxl_print_html($settings['suffix']); ?></span>
                    <?php endif; ?>
                </div>
                <?php if(!empty($settings['title'])) : ?>
                    <div class="pxl--item-title"><?php echo pxl_print_html($settings['title']); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="pxl-inner-image">
            <div class="pxl-content-image image1">
                <?php if(!empty($settings['image']['id'])) : 
                    $image_size = !empty($settings['img_size']) ? $settings['img_size'] : '700x730'; 
                    $img = pxl_get_image_by_size( array(
                        'attach_id'  => $settings['image']['id'],
                        'thumb_size' => $image_size,
                    ));
                    $thumbnail = $img['thumbnail'];
                    ?>
                    <div class="pxl-item--image1 image">
                        <div class="pxl-item--imgprimary <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
                            <?php echo pxl_print_html($thumbnail); ?>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(!empty($settings['image2']['id'])) : 
                    $img_2 = pxl_get_image_by_size( array(
                        'attach_id'  => $settings['image2']['id'],
                        'thumb_size' => '700x730',
                    ));
                    $thumbnail_2 = $img_2['thumbnail']; ?>
                    <div class="pxl-item--image2 image <?php echo esc_attr($settings['pxl_animate_img2']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img2']); ?>ms"><?php echo pxl_print_html($thumbnail_2); ?></div>
                <?php endif; ?>
            </div>
            <div class="pxl-content-image image2">
                <?php if(!empty($settings['image3']['id'])) : 
                    $img_3 = pxl_get_image_by_size( array(
                        'attach_id'  => $settings['image3']['id'],
                        'thumb_size' => '700x730',
                    ));
                    $thumbnail_3 = $img_3['thumbnail']; ?>
                    <div class="pxl-item--image3 image <?php echo esc_attr($settings['pxl_animate_img3']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img3']); ?>ms"><?php echo pxl_print_html($thumbnail_3); ?></div>
                <?php endif; ?>
                <?php if(!empty($settings['image4']['id'])) : 
                    $img_4 = pxl_get_image_by_size( array(
                        'attach_id'  => $settings['image4']['id'],
                        'thumb_size' => '700x730',
                    ));
                    $thumbnail_4 = $img_4['thumbnail']; ?>
                    <div class="pxl-item--image4 image <?php echo esc_attr($settings['pxl_animate_img4']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img4']); ?>ms"><?php echo pxl_print_html($thumbnail_4); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>