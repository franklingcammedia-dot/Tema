<?php
if ( ! empty( $settings['button_link']['url'] ) ) {
    $widget->add_render_attribute( 'button', 'href', $settings['button_link']['url'] );

    if ( $settings['button_link']['is_external'] ) {
        $widget->add_render_attribute( 'button', 'target', '_blank' );
    }

    if ( $settings['button_link']['nofollow'] ) {
        $widget->add_render_attribute( 'button', 'rel', 'nofollow' );
    }
}
?>
<div class="pxl-pricing pxl-pricing3 <?php echo esc_attr($settings['pxl_animate'].' '.$settings['popular']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-content-top">
        <div class="pxl-sub-title"><?php echo esc_attr($settings['sub_title']); ?></div>
        <h5 class="pxl-item--title el-empty"><span><?php echo esc_attr($settings['title']); ?></span></h5>
    </div>
    <div class="pxl-content">
        <div class="pxl-item--meta">
            <div class="pxl-inner-icon">
                <div class="pxl-item--price">
                    <div class="pxl-price">
                        <?php echo pxl_print_html($settings['price']); ?>
                    </div>
                    <span class="pxl-item--currency"><?php echo pxl_print_html($settings['currency']); ?></span>
                    <div class="pxl-item--time el-empty"><?php echo pxl_print_html($settings['time']); ?></div>
                </div>
                <div class="pxl-content-icon">
                    <?php if ( $settings['icon_type'] == 'icon' && !empty($settings['pxl_icon']['value']) ) : ?>
                        <div class="pxl-item--icon1 icon">
                            <?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                        </div>
                    <?php endif; ?>
                    <?php if ( $settings['icon_type2'] == 'icon2' && !empty($settings['pxl_icon2']['value']) ) : ?>
                        <div class="pxl-item--icon2 icon">
                            <?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon2'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="pxl-item--desc">
                <?php echo pxl_print_html($settings['desc']); ?>
            </div>
            <?php if(isset($settings['feature']) && !empty($settings['feature']) && count($settings['feature'])): ?>
                <div class="pxl-item--feature">
                    <?php foreach ($settings['feature'] as $key => $value): ?>
                        <div class="pxl-feature-list">
                            <div class="pxl-icon">
                                <i class="caseicon-check"></i>
                            </div>
                            <div class="pxl-feature-text">
                                <?php echo pxl_print_html($value['feature_text'])?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php if(!empty($settings['button_text'])) : ?>
            <div class="pxl-item--button">
                <a class="btn-shape-primary btn-flex" <?php pxl_print_html($widget->get_render_attribute_string( 'button' )); ?>>
                    <span class="pxl-mr-10"><?php echo esc_attr($settings['button_text']); ?></span>
                    <i class="far fa-plus"></i>
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>