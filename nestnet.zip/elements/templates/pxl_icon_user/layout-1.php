<?php 
$default_settings = [
    'style' => '',
    'text_placeholder' => '',
    'text_button' => '',
    'post_type' => '',
    'quick_user' => '',
];
$settings = array_merge($default_settings, $settings);
extract($settings);
?>

<div class="pxl-icon--users icon-item h-btn-user <?php echo esc_attr($settings['style']) ?>">
	<div class="title"><?php echo esc_attr($settings['title']); ?> <i class="flaticon flaticon-right"></i></div>
	<?php if(is_user_logged_in()) : ?>
		<ul class="pxl-user-account">
			<?php if(class_exists('WooCommerce') ) :
				$my_ac = get_option( 'woocommerce_myaccount_page_id' ); 
				?>
				<li><a href="<?php echo esc_url(get_permalink($my_ac)); ?>"><?php echo esc_html__('My Account', 'nestnet'); ?></a></li>
			<?php endif; ?>
			<li><a href="<?php echo esc_url(wp_logout_url()); ?>"><?php echo esc_html__('Log Out', 'nestnet'); ?></a></li>
		</ul>
	<?php endif; ?>
</div> 