<?php
$html_id = pxl_get_element_id($settings);
if ( ! empty( $settings['button_link']['url'] ) ) {
    $widget->add_render_attribute( 'button', 'href', $settings['button_link']['url'] );

    if ( $settings['button_link']['is_external'] ) {
        $widget->add_render_attribute( 'button', 'target', '_blank' );
    }

    if ( $settings['button_link']['nofollow'] ) {
        $widget->add_render_attribute( 'button', 'rel', 'nofollow' );
    }
}
?>
<div class="pxl-icon-box pxl-icon-box7 <?php echo esc_attr($settings['style'].' '.$settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-item--inner">
        <?php if(!empty($settings['image_bg']['id'])) : 
            $image_size = !empty($settings['img_size']) ? $settings['img_size'] : '570x560'; 
            $img = pxl_get_image_by_size( array(
                'attach_id'  => $settings['image_bg']['id'],
                'thumb_size' => $image_size,
            ));
            $thumbnail = $img['thumbnail'];
            ?>
            <div class="pxl-item--bg">
                <div class="pxl-item--img-bg">
                    <?php echo pxl_print_html($thumbnail); ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="pxl-item-wrap">
            <?php if ( $settings['icon_type'] == 'icon' && !empty($settings['pxl_icon']['value']) ) : ?>
                <div class="pxl-item--icon">
                    <?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                </div>
            <?php endif; ?>
            <?php if ( $settings['icon_type'] == 'image' && !empty($settings['icon_image']['id']) ) : ?>
                <div class="pxl-item--icon">
                    <?php $img_icon  = pxl_get_image_by_size( array(
                            'attach_id'  => $settings['icon_image']['id'],
                            'thumb_size' => 'full',
                        ) );
                        $thumbnail_icon    = $img_icon['thumbnail'];
                    echo pxl_print_html($thumbnail_icon); ?>
                </div>
            <?php endif; ?>
            <div class="pxl-item--holder">
                <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-item--title el-empty"><?php echo pxl_print_html($settings['title']); ?></<?php echo esc_attr($settings['title_tag']); ?>>
                <div class="pxl-text">
                    <?php echo pxl_print_html($settings['text']); ?>
                </div>
                <?php if(!empty($settings['button_text'])) : ?>
                    <div class="pxl-item--button">
                        <a class="btn-shape-primary btn-flex" <?php pxl_print_html($widget->get_render_attribute_string( 'button' )); ?>>
                            <span><?php echo esc_attr($settings['button_text']); ?></span>
                            <i class="flaticon flaticon-right"></i>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>