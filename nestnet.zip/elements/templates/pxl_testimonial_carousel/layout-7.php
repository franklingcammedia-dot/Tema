<?php
$col_xs = $widget->get_setting('col_xs', '');
$col_sm = $widget->get_setting('col_sm', '');
$col_md = $widget->get_setting('col_md', '');
$col_lg = $widget->get_setting('col_lg', '');
$col_xl = $widget->get_setting('col_xl', '');
$col_xxl = $widget->get_setting('col_xxl', '');
if($col_xxl == 'inherit') {
    $col_xxl = $col_xl;
}
$slides_to_scroll = $widget->get_setting('slides_to_scroll', '');
$arrows = $widget->get_setting('arrows','false');
$show_star_lv7 = $widget->get_setting('show_star_lv7');
$pagination = $widget->get_setting('pagination','false');
$pagination_type = $widget->get_setting('pagination_type','bullets');
$pause_on_hover = $widget->get_setting('pause_on_hover');
$autoplay = $widget->get_setting('autoplay', '');
$autoplay_speed = $widget->get_setting('autoplay_speed', '5000');
$infinite = $widget->get_setting('infinite','false');  
$drap = $widget->get_setting('drap','false');  
$speed = $widget->get_setting('speed', '500');
$opts = [
    'slide_direction'               => 'horizontal',
    'slide_percolumn'               => '1', 
    'slide_mode'                    => 'slide', 
    'slides_to_show'                => $col_xl, 
    'slides_to_show_xxl'             => $col_xxl, 
    'slides_to_show_lg'             => $col_lg, 
    'slides_to_show_md'             => $col_md, 
    'slides_to_show_sm'             => $col_sm, 
    'slides_to_show_xs'             => $col_xs, 
    'slides_to_scroll'              => $slides_to_scroll,
    'arrow'                         => $arrows,
    'pagination'                    => $pagination,
    'pagination_type'               => $pagination_type,
    'pagination_number'             => 'true',
    'autoplay'                      => $autoplay,
    'pause_on_hover'                => $pause_on_hover,
    'pause_on_interaction'          => 'true',
    'delay'                         => $autoplay_speed,
    'loop'                          => $infinite,
    'speed'                         => $speed,
];
$widget->add_render_attribute( 'carousel', [
    'class'         => 'pxl-swiper-container',
    'dir'           => is_rtl() ? 'rtl' : 'ltr',
    'data-settings' => wp_json_encode($opts)
]);
if(isset($settings['testimonial_lv7']) && !empty($settings['testimonial_lv7']) && count($settings['testimonial_lv7'])):
$image_size = !empty($settings['img_size']) ? $settings['img_size'] : '70x70'; ?>
    <div class="pxl-swiper-sliders pxl-testimonial-carousel pxl-testimonial-carousel7 pxl-swiper-boxshadow pxl-testimonial-style7" <?php if($drap !== 'false') : ?>data-cursor-drap="<?php echo esc_html('DRAG', 'nestnet'); ?>"<?php endif; ?>>
        <?php if($arrows !== 'false'): ?>
            <div class="pxl-swiper-arrow-wrap">
                <div class="pxl-swiper-arrow pxl-swiper-arrow-prev"><i class="far fa-arrow-left rtl-icon"></i></div>
                <div class="pxl-swiper-arrow pxl-swiper-arrow-next"><i class="far fa-arrow-right rtl-icon"></i></div>
            </div>
        <?php endif; ?>

        <div class="pxl-carousel-inner">
            <div <?php pxl_print_html($widget->get_render_attribute_string( 'carousel' )); ?>>
                <div class="pxl-swiper-wrapper">
                    <?php foreach ($settings['testimonial_lv7'] as $key => $value):
                        $title_lv7 = isset($value['title_lv7']) ? $value['title_lv7'] : '';
                        $desc_lv7 = isset($value['desc_lv7']) ? $value['desc_lv7'] : '';
                        $sub_title_lv7 = isset($value['sub_title_lv7']) ? $value['sub_title_lv7'] : '';
                        $image_lv7 = isset($value['image_lv7']) ? $value['image_lv7'] : '';
                        $style_star_lv7 = isset($value['style_star_lv7']) ? $value['style_star_lv7'] : '';
                        $number_lv7 = isset($value['number_lv7']) ? $value['number_lv7'] : '';
                        ?>
                        <div class="pxl-swiper-slide">
                            <div class="pxl-item--inner <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
                                <div class="pxl-content-inner">
                                    <div class="pxl-item--content">
                                        <?php if(!empty($image_lv7['id'])) { 
                                            $img = pxl_get_image_by_size( array(
                                                'attach_id'  => $image_lv7['id'],
                                                'thumb_size' => $image_size,
                                                'class' => 'no-lazyload',
                                            ));
                                            $thumbnail = $img['thumbnail'];
                                            ?>
                                            <div class="pxl-item--image pxl-mr-20">
                                                <?php echo wp_kses_post($thumbnail); ?>
                                            </div>
                                        <?php } ?>
                                        <div class="pxl-layout">
                                            <h5 class="pxl-item--title"><?php echo pxl_print_html($title_lv7); ?></h5>
                                            <div class="pxl-item--sub"><?php echo pxl_print_html($sub_title_lv7); ?></div>
                                        </div>
                                    </div>
                                    <div class="pxl-item-star">
                                        <?php if( $show_star_lv7 == 'true' ) : ?>
                                            <span class="item-star <?php echo esc_attr( $style_star_lv7 ); ?>">
                                                <i class="caseicon-star"></i>
                                                <i class="caseicon-star"></i>
                                                <i class="caseicon-star"></i>
                                                <i class="caseicon-star"></i>
                                                <i class="caseicon-star"></i>
                                            </span>
                                        <?php endif; ?>
                                        <div class="pxl-item--number"><?php echo pxl_print_html($number_lv7); ?></div>
                                    </div>
                                </div>
                                <div class="pxl-item--desc">
                                    <?php echo pxl_print_html($desc_lv7); ?>   
                                </div>
                           </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?php if($pagination !== 'false'): ?>
            <div class="pxl-swiper-dots style-1"></div>
        <?php endif; ?>
        
    </div>
<?php endif; ?>
