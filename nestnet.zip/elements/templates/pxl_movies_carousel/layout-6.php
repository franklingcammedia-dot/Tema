<?php
$col_xs = $widget->get_setting('col_xs', '');
$col_sm = $widget->get_setting('col_sm', '');
$col_md = $widget->get_setting('col_md', '');
$col_lg = $widget->get_setting('col_lg', '');
$col_xl = $widget->get_setting('col_xl', '');
$col_xxl = $widget->get_setting('col_xxl', '');
if($col_xxl == 'inherit') {
    $col_xxl = $col_xl;
}
$slides_to_scroll = $widget->get_setting('slides_to_scroll', '');
$arrows = $widget->get_setting('arrows','false');  
$pagination = $widget->get_setting('pagination','false');
$pagination_type = $widget->get_setting('pagination_type','bullets');
$pause_on_hover = $widget->get_setting('pause_on_hover');
$autoplay = $widget->get_setting('autoplay', '');
$autoplay_speed = $widget->get_setting('autoplay_speed', '5000');
$infinite = $widget->get_setting('infinite','false');  
$drap = $widget->get_setting('drap','false');  
$speed = $widget->get_setting('speed', '500');
$opts = [
    'slide_direction'               => 'horizontal',
    'slide_percolumn'               => '1', 
    'slide_mode'                    => 'slide', 
    'slides_to_show'                => $col_xl, 
    'slides_to_show_xxl'             => $col_xxl, 
    'slides_to_show_lg'             => $col_lg, 
    'slides_to_show_md'             => $col_md, 
    'slides_to_show_sm'             => $col_sm, 
    'slides_to_show_xs'             => $col_xs, 
    'slides_to_scroll'              => $slides_to_scroll,
    'arrow'                         => $arrows,
    'pagination'                    => $pagination,
    'pagination_type'               => $pagination_type,
    'pagination_number'             => 'true',
    'autoplay'                      => $autoplay,
    'pause_on_hover'                => $pause_on_hover,
    'pause_on_interaction'          => 'true',
    'delay'                         => $autoplay_speed,
    'loop'                          => $infinite,
    'speed'                         => $speed,
];
$widget->add_render_attribute( 'carousel', [
    'class'         => 'pxl-swiper-container',
    'dir'           => is_rtl() ? 'rtl' : 'ltr',
    'data-settings' => wp_json_encode($opts)
]);
if(isset($settings['movies_lv6']) && !empty($settings['movies_lv6']) && count($settings['movies_lv6'])):
$image_size = !empty($settings['img_size']) ? $settings['img_size'] : '600x805'; ?>
    <div class="pxl-swiper-sliders pxl-movies-carousel pxl-movies-carousel6 pxl-swiper-boxshadow pxl-movies-style6" <?php if($drap !== 'false') : ?>data-cursor-drap="<?php echo esc_html('DRAG', 'nestnet'); ?>"<?php endif; ?>>
        <?php if($arrows !== 'false'): ?>
            <div class="pxl-swiper-arrow-wrap">
                <div class="pxl-swiper-arrow pxl-swiper-arrow-prev"><i class="far fa-arrow-left rtl-icon"></i></div>
                <div class="pxl-swiper-arrow pxl-swiper-arrow-next"><i class="far fa-arrow-right rtl-icon"></i></div>
            </div>
        <?php endif; ?>

        <div class="pxl-carousel-inner">
            <div <?php pxl_print_html($widget->get_render_attribute_string( 'carousel' )); ?>>
                <div class="pxl-swiper-wrapper">
                    <?php foreach ($settings['movies_lv6'] as $key => $value):
                        $imdb_title_lv6 = isset($value['imdb_title_lv6']) ? $value['imdb_title_lv6'] : '';
                        $title_lv6 = isset($value['title_lv6']) ? $value['title_lv6'] : '';
                        $sub_title_lv6 = isset($value['sub_title_lv6']) ? $value['sub_title_lv6'] : '';
                        $image_lv6 = isset($value['image_lv6']) ? $value['image_lv6'] : '';
                        $link_key = $widget->get_repeater_setting_key( 'link_play_lv6', 'value', $key );
                        if ( ! empty( $value['link_play_lv6']['url'] ) ) {
                            $widget->add_render_attribute( $link_key, 'href', $value['link_play_lv6']['url'] );

                            if ( $value['link_play_lv6']['is_external'] ) {
                                $widget->add_render_attribute( $link_key, 'target', '_blank' );
                            }

                            if ( $value['link_play_lv6']['nofollow'] ) {
                                $widget->add_render_attribute( $link_key, 'rel', 'nofollow' );
                            }
                        }
                        $link_attributes = $widget->get_render_attribute_string( $link_key ); ?>
                        <div class="pxl-swiper-slide">
                            <div class="pxl-item--inner <?php echo esc_attr($settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
                                <a class="pxl-image-link btn-video" <?php echo implode( ' ', [ $link_attributes ] ); ?>>
                                    <div class="pxl-item-meta">
                                        <?php if(!empty($image_lv6['id'])) { 
                                            $img = pxl_get_image_by_size( array(
                                                'attach_id'  => $image_lv6['id'],
                                                'thumb_size' => $image_size,
                                                'class' => 'no-lazyload',
                                            ));
                                            $thumbnail = $img['thumbnail'];
                                            ?>
                                            <div class="pxl-item--image">
                                                <?php echo wp_kses_post($thumbnail); ?>
                                            </div>
                                        <?php } ?>
                                        <div class="pxl-item--imdb-title"><?php echo pxl_print_html($imdb_title_lv6); ?></div>
                                    </div>

                                    <div class="pxl-content-title">
                                        <div class="pxl-title">
                                            <?php echo pxl_print_html($title_lv6); ?>
                                        </div>
                                        <div class="pxl-sub-title">
                                            <?php echo pxl_print_html($sub_title_lv6); ?>
                                        </div>
                                    </div>
                                </a>
                           </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?php if($pagination !== 'false'): ?>
            <div class="pxl-swiper-dots style-1"></div>
        <?php endif; ?>
        
    </div>
<?php endif; ?>
