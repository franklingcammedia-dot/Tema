<div class="pxl-banner-box pxl-banner-box2">
	<div class="pxl-box-inner">
		
		<?php if(!empty($settings['banner_image']['id'])) : 
			$image_size = !empty($settings['img_size']) ? $settings['img_size'] : '420x535'; 
			$img = pxl_get_image_by_size( array(
				'attach_id'  => $settings['banner_image']['id'],
				'thumb_size' => $image_size,
			));
			$thumbnail = $img['thumbnail'];
			?>
			<div class="pxl-item--meta">
				<div class="pxl-group"></div>
				<div class="pxl-item--imgprimary <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
					<?php echo pxl_print_html($thumbnail); ?>
					<div class="pxl-divide--group  wow" data-wow-delay="120ms">
						<div class="pxl-item--divider pxl-divider--top"></div>
						<div class="pxl-item--divider pxl-divider--right"></div>
						<div class="pxl-item--divider pxl-divider--bottom"></div>
						<div class="pxl-item--divider pxl-divider--left"></div>
					</div>
				</div>
				<?php if(!empty($settings['banner_image2']['id'])) : 
					$img_2 = pxl_get_image_by_size( array(
						'attach_id'  => $settings['banner_image2']['id'],
						'thumb_size' => '270x227',
					));
					$thumbnail_2 = $img_2['thumbnail']; ?>
					<div class="pxl-item--imgsecondary <?php echo esc_attr($settings['pxl_animate_img2']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img2']); ?>ms"><?php echo pxl_print_html($thumbnail_2); ?></div>
				<?php endif; ?>
				<div class="content-inner">
					<div class="content-text <?php echo esc_attr($settings['pxl_animate_img3']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img3']); ?>ms">
						<h2 class="title"><?php echo esc_attr($settings['title']); ?></h2>
						<div class="sub-title">
							<?php echo esc_attr($settings['sub_title']); ?>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>