<div class="pxl-banner-box pxl-banner-box3">
	<div class="pxl-box-inner">
		
		<?php if(!empty($settings['banner_image']['id'])) : 
			$image_size = !empty($settings['img_size']) ? $settings['img_size'] : '295x295'; 
			$img = pxl_get_image_by_size( array(
				'attach_id'  => $settings['banner_image']['id'],
				'thumb_size' => $image_size,
			));
			$thumbnail = $img['thumbnail'];
			?>
			<div class="pxl-item--meta">
				<div class="pxl-group <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
					<div class="pxl-item-layout1 image-layout">
						<div class="pxl-item--image1 image">
							<?php echo pxl_print_html($thumbnail); ?>
						</div>
						<?php if(!empty($settings['banner_image2']['id'])) : 
							$img_2 = pxl_get_image_by_size( array(
								'attach_id'  => $settings['banner_image2']['id'],
								'thumb_size' => '295x295',
							));
							$thumbnail_2 = $img_2['thumbnail']; ?>
							<div class="pxl-item--image2 image"><?php echo pxl_print_html($thumbnail_2); ?></div>
						<?php endif; ?>
					</div>

					<div class="pxl-item-layout2 image-layout">
						<?php if(!empty($settings['banner_image3']['id'])) : 
							$img_3 = pxl_get_image_by_size( array(
								'attach_id'  => $settings['banner_image3']['id'],
								'thumb_size' => '295x295',
							));
							$thumbnail_3 = $img_3['thumbnail']; ?>
							<div class="pxl-item--image3 image"><?php echo pxl_print_html($thumbnail_3); ?></div>
						<?php endif; ?>

						<?php if(!empty($settings['banner_image4']['id'])) : 
							$img_4 = pxl_get_image_by_size( array(
								'attach_id'  => $settings['banner_image4']['id'],
								'thumb_size' => '295x295',
							));
							$thumbnail_4 = $img_4['thumbnail']; ?>
							<div class="pxl-item--image4 image"><?php echo pxl_print_html($thumbnail_4); ?></div>
						<?php endif; ?>
					</div>
				</div>
				<div class="content-inner <?php echo esc_attr($settings['pxl_animate_img2']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img2']); ?>ms">
					<div class="content-text">
						<h2 class="title"><?php echo esc_attr($settings['title']); ?></h2>
						<div class="sub-title">
							<?php echo esc_attr($settings['sub_title']); ?>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>