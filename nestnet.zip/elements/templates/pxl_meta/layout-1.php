<div class="pxl-meta pxl-meta1">
	<div class="pxl-meta-inner <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
		<div class="pxl-meta-content pxl-meta-content1">
			<div class="content-inner content-inner1">
				<h5 class="title"><?php echo esc_attr($settings['title']); ?></h5>
				<div class="sub-title">
					<?php echo esc_attr($settings['sub_title']); ?>
				</div>
			</div>
			<div class="content-inner">
				<h5 class="title title2"><?php echo esc_attr($settings['title2']); ?></h5>
				<div class="sub-title sub-title2">
					<?php echo esc_attr($settings['sub_title2']); ?>
				</div>
			</div>
		</div>
		<div class="pxl-meta-content pxl-meta-content2">
			<div class="content-inner">
				<h5 class="title title3"><?php echo esc_attr($settings['title3']); ?></h5>
				<div class="sub-title sub-title3">
					<?php echo esc_attr($settings['sub_title3']); ?>
				</div>
			</div>
			<div class="content-inner">
				<h5 class="title title4"><?php echo esc_attr($settings['title4']); ?></h5>
				<div class="sub-title sub-title4">
					<?php echo esc_attr($settings['sub_title4']); ?>
				</div>
			</div>
		</div>
	</div>
</div>