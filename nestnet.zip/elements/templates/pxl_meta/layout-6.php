<div class="pxl-meta pxl-meta6">
	<div class="pxl-meta-inner <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
		<div class="pxl-meta-content">
			<div class="content-inner">
				<div class="pxl-item-title">
					<h5 class="title"><?php echo esc_attr($settings['title']); ?></h5>
				</div>
				<div class="sub-title">
					<?php echo esc_attr($settings['sub_title']); ?>
				</div>
			</div>
		</div>
	</div>
</div>