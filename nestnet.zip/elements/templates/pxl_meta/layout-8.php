<?php
$html_id = pxl_get_element_id($settings);
?>
<div class="pxl-meta pxl-meta8">
	<div class="pxl-meta-inner <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
		<div class="content-inner">
			<div class="pxl-meta-content">
				<?php if ( $settings['icon_type'] == 'icon' && !empty($settings['pxl_icon']['value']) ) : ?>
	                <div class="pxl-item--icon pxl-mr-10">
	                    <?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
	                </div>
	            <?php endif; ?>
				<div class="pxl-item-title">
					<h5 class="title"><?php echo esc_attr($settings['title']); ?></h5>
				</div>
			</div>
			<div class="sub-title">
				<?php echo esc_attr($settings['sub_title']); ?>
			</div>
		</div>
	</div>
</div>