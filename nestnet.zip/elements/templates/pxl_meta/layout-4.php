<div class="pxl-meta pxl-meta4">
	<div class="pxl-meta-inner <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
		<div class="pxl-meta-content">
			<?php if(!empty($settings['banner_image']['id'])) : 
				$image_size = !empty($settings['img_size']) ? $settings['img_size'] : '70x70';
				$img = pxl_get_image_by_size( array(
					'attach_id'  => $settings['banner_image']['id'],
					'thumb_size' => $image_size,
				));
				$thumbnail = $img['thumbnail'];
				?>
				<div class="pxl-item--imgprimary pxl-mr-20">
					<?php echo pxl_print_html($thumbnail); ?>
				</div>
				<div class="content-inner">
					<div class="pxl-item-title">
						<h5 class="title"><?php echo esc_attr($settings['title']); ?></h5>
					</div>
					<div class="sub-title">
						<?php echo esc_attr($settings['sub_title']); ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>