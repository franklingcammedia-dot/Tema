<div class="pxl-author pxl-author1">
	<div class="pxl-author-inner <?php echo esc_attr($settings['pxl_animate_img1']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay_img1']); ?>ms">
		
		<?php if(!empty($settings['banner_image']['id'])) : 
			$img = pxl_get_image_by_size( array(
				'attach_id'  => $settings['banner_image']['id'],
			));
			$thumbnail = $img['thumbnail'];
			?>
			<div class="pxl-item--imgprimary pxl-mr-20">
				<?php echo pxl_print_html($thumbnail); ?>
			</div>
			<div class="content-inner">
				<div class="content-style">
					<h5 class="title"><?php echo esc_attr($settings['title']); ?></h5>
					<div class="sub-title">
						<?php echo esc_attr($settings['sub_title']); ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>