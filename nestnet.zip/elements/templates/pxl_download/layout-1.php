<?php
$html_id = pxl_get_element_id($settings);
if ( ! empty( $settings['link']['url'] ) ) {
    $widget->add_render_attribute( 'link_text', 'href', $settings['link']['url'] );

    if ( $settings['link']['is_external'] ) {
        $widget->add_render_attribute( 'link_text', 'target', '_blank' );
    }

    if ( $settings['link']['nofollow'] ) {
        $widget->add_render_attribute( 'link_text', 'rel', 'nofollow' );
    }
}

if ( ! empty( $settings['link2']['url'] ) ) {
    $widget->add_render_attribute( 'link_text2', 'href', $settings['link2']['url'] );

    if ( $settings['link2']['is_external'] ) {
        $widget->add_render_attribute( 'link_text2', 'target', '_blank' );
    }

    if ( $settings['link2']['nofollow'] ) {
        $widget->add_render_attribute( 'link_text2', 'rel', 'nofollow' );
    }
}
?>
<div class="pxl-download pxl-download1 <?php echo esc_attr($settings['style'].' '.$settings['pxl_animate']); ?>" data-wow-delay="<?php echo esc_attr($settings['pxl_animate_delay']); ?>ms">
    <div class="pxl-item--inner">
        <div class="pxl-item-wrap">
            <div class="pxl-item--holder">
                <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-item--title el-empty"><?php echo pxl_print_html($settings['title']); ?></<?php echo esc_attr($settings['title_tag']); ?>>
                <ul class="pxl-link-text">
                    <li class="pxl-item--text1 text">
                        <a <?php pxl_print_html($widget->get_render_attribute_string( 'link_text' )); ?>>
                            <?php if ( $settings['icon_type'] == 'icon' && !empty($settings['pxl_icon']['value']) ) : ?>
                                <div class="pxl-item--icon pxl-mr-10">
                                    <?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                                </div>
                            <?php endif; ?>
                           <?php echo pxl_print_html($settings['link_text1']); ?>
                        </a>
                    </li>
                    <li class="pxl-item--text2 text">
                        <a <?php pxl_print_html($widget->get_render_attribute_string( 'link_text2' )); ?>>
                            <?php if ( $settings['icon_type'] == 'icon' && !empty($settings['pxl_icon']['value']) ) : ?>
                                <div class="pxl-item--icon pxl-mr-10">
                                    <?php \Elementor\Icons_Manager::render_icon( $settings['pxl_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                                </div>
                            <?php endif; ?>
                            <?php echo pxl_print_html($settings['link_text2']); ?>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>